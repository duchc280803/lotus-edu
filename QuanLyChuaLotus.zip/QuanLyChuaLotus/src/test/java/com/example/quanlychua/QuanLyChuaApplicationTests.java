package com.example.quanlychua;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanLyChuaApplicationTests {

	@Test
	void contextLoads() {
	}

}
