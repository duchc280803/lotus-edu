package com.example.quanlychua.service;

public interface NguoiDungBinhLuanBaiVietService {
}
