package com.example.quanlychua.enums;

public enum TokenType {
    BEARER
}
