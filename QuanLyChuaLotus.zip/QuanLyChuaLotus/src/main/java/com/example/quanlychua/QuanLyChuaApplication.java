package com.example.quanlychua;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanLyChuaApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuanLyChuaApplication.class, args);
	}

}
